create definer = root@localhost trigger board_OnInsert
    before insert
    on board
    for each row
    SET NEW.board_date = NOW();

